using System;
using System.Linq;

class MainClass {
  public static void Main (string[] args) {

    //sets how many times the for loop runs
    int limit = 1000;

    //this is the second number the 3 and 5 gets multiplied by
    int count = 1;

    //used to store the multiple into the array
    int num = 0;

    //array to save the multiples
    int[] multiples = new int[limit];

    //the sum default 
    int sum = 0;

    for (int i = 0; i != limit / 2; i++) {
      
      //multiplies 3 and 5 by the count
      int ThreeAnswer = 3 * count;
      int FiveAnswer = 5 * count;

      count++;

      //Checks if the answer is over the limit and if it is ignores it
      if (ThreeAnswer < limit) {
        multiples[num] = ThreeAnswer;
        num++;
      }
      if (FiveAnswer < limit) {
        multiples[num] = FiveAnswer;
        num++;
      }

    }
    Array.Sort(multiples);
    //writes all Distinct multiples out into a new array
    int[] dist = multiples.Distinct().ToArray();

    //writes out the numbers in the array if they are greater than 0
    for (int l = 0; l != dist.Length; l++) {
      if (dist[l] != 0) {
        sum += dist[l];
        //Console.WriteLine(multiples[l]);
      }
    }
    Console.WriteLine(sum);
  }
}